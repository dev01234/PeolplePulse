import {
    Dialog,
    DialogContent,
    DialogDescription,
    DialogFooter,
    DialogHeader,
    DialogTitle,
    DialogTrigger,
  } from "../ui/dialog";
  import { Button } from "../ui/button";
  import api from "@/lib/axiosInstance";
  import { useState } from "react";
  
  interface DeleteProjectProps {
    id: string;
    type: string;
    onDelete: (id: string) => void; // Function to handle delete in AdminTable
  }
  
  const DeleteProject = ({ id, onDelete, type }: DeleteProjectProps) => {
    const handleDelete = async() => {
      console.log(id);
      try {
          const res = await api.delete(`/users/deleteuser/${id}`)
          console.log("User deleted successfully", res);
          onDelete(id); 
      } catch (error) {
          console.log("Error deleting user", error)
      }
    };
    return (
      <Dialog>
        <DialogTrigger asChild>
          <Button className=" bg-blue-500" variant="default">
            Delete
          </Button>
        </DialogTrigger>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Are you absolutely sure?</DialogTitle>
            <DialogDescription>
              This will permanently delete the user
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button type="submit" onClick={handleDelete}>
              Delete user
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    );
  };
  
  export default DeleteProject;
  