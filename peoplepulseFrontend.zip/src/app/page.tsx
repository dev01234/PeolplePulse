import Image from "next/image";
import AdminPage from "./admin/page";

export default function Home() {
  return (
   <AdminPage/>
  );
}
